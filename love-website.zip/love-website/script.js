const files=['photo1.jpg','photo2.jpg','photo3.jpg','photo4.jpg','photo5.jpg','photo6.jpg','photo7.jpg','photo8.jpg','photo9.jpg'];let i=0;
const d=document.getElementById('slideshow');function show(){d.innerHTML=`<img src="images/${files[i]}">`;i=(i+1)%files.length;}
show();setInterval(show,3000);