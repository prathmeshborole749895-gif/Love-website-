Copy your uploaded photos into the images folder and rename them:
photo1.jpg ... photo9.jpg
Then upload the folder to GitHub Pages.